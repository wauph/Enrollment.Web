﻿namespace Enrollment.Web.ViewModel.Student
{
    public class EditViewModel
    {
    }
}
