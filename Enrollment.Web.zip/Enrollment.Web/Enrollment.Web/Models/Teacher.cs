﻿namespace Enrollment.Web.Models
{
    public class Teacher
    {
        public string TeacherID { get; set; }
        public string TeacherName { get; set; }
    }
}
